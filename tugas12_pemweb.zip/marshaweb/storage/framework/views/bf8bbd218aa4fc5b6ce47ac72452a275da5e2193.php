
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">Contact Form</div>
    <div class="card-body">
        <h2>Welcome!!!</h2>
    </div>
</div>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\marshaweb\resources\views/login/home.blade.php ENDPATH**/ ?>